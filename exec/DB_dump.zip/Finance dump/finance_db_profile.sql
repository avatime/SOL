-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a403.p.ssafy.io    Database: finance_db
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile` (
  `pf_id` int unsigned NOT NULL AUTO_INCREMENT,
  `pf_img` varchar(255) NOT NULL,
  `pf_name` varchar(255) NOT NULL,
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/001-parrot.png','parrot'),(2,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/002-penguin.png','penguin'),(3,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/003-giraffe.png','giraffe'),(4,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/004-bear.png','bear'),(5,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/005-puffer+fish.png','puffer fish'),(6,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/006-sloth.png','sloth'),(7,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/007-gorilla.png','gorilla'),(8,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/008-fox.png','fox'),(9,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/009-zebra.png','zebra'),(10,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/010-bat.png','bat'),(11,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/011-owl.png','owl'),(12,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/012-crab.png','crab'),(13,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/013-llama.png','llama'),(14,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/014-snake.png','snake'),(15,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/015-wolf.png','wolf'),(16,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/016-lion.png','lion'),(17,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/017-goat.png','goat'),(18,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/018-rabbit.png','rabbit'),(19,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/019-ferret.png','ferret'),(20,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/020-mouse.png','mouse'),(21,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/021-turtle.png','turtle'),(22,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/022-hen.png','hen'),(23,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/023-pig.png','pig'),(24,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/024-hedgehog.png','hedgehog'),(25,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/025-walrus.png','walrus'),(26,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/026-skunk.png','skunk'),(27,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/027-frog.png','frog'),(28,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/028-chameleons.png','chameleons'),(29,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/029-squirrel.png','squirrel'),(30,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/030-rhino.png','rhino'),(31,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/031-ostrich.png','ostrich'),(32,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/032-hippopotamus.png','hippopotamus'),(33,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/033-koala.png','koala'),(34,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/034-camel.png','camel'),(35,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/035-beaver.png','beaver'),(36,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/036-dog.png','dog'),(37,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/037-turkey.png','turkey'),(38,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/038-deer.png','deer'),(39,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/039-cow.png','cow'),(40,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/040-elephant.png','elephant'),(41,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/041-chicken.png','chicken'),(42,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/042-duck.png','duck'),(43,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/043-wild+boar.png','wild boar'),(44,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/044-bee.png','bee'),(45,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/045-horse.png','horse'),(46,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/046-sheep.png','sheep'),(47,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/047-panda.png','panda'),(48,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/048-monkey.png','monkey'),(49,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/049-cat.png','cat'),(50,'https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/profile/050-octopus.png','octopus');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 11:10:46
