-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a403.p.ssafy.io    Database: finance_db
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `corporation`
--

DROP TABLE IF EXISTS `corporation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corporation` (
  `cp_code` int NOT NULL AUTO_INCREMENT,
  `cp_name` varchar(16) DEFAULT NULL,
  `cp_logo` varchar(675) DEFAULT NULL,
  PRIMARY KEY (`cp_code`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corporation`
--

LOCK TABLES `corporation` WRITE;
/*!40000 ALTER TABLE `corporation` DISABLE KEYS */;
INSERT INTO `corporation` VALUES (1,'신한','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/01_신한.png'),(2,'기업','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/02_기업.png'),(3,'NH농협','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/03_농협.png'),(4,'하나','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/04_하나.png'),(5,'우리','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/05_우리.png'),(6,'국민','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/05_국민.png'),(7,'우체국','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/07_우체국.png'),(8,'카카오뱅크','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/08_카카오뱅크.jpg'),(9,'케이뱅크','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/09_케이뱅크.jpg'),(10,'토스뱅크','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/10_토스뱅크.png'),(11,'새마을금고','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/11_새마을금고.png'),(12,'씨티','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/12_씨티.png'),(13,'산업','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/13_산업.png'),(14,'경남','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/14_경남.png'),(15,'광주','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/15_광주.png'),(16,'대구','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/16_대구.png'),(17,'현대카드','https://upload.wikimedia.org/wikipedia/commons/f/f0/Hyundai_card_CI_new.png'),(18,'우리카드','http://m.asunmall.kr/web/product/medium/201808/0ba1737eb6a71bf7efc6d17f51170260.jpg'),(19,'NH농협카드','https://mblogthumb-phinf.pstatic.net/20160501_161/ppanppane_146206873822759cXx_PNG/%B8%F1%BF%EC%C3%CC_%B7%CE%B0%ED_%282%29.png?type=w800'),(20,'삼성카드','http://wiki.hash.kr/images/4/4c/%EC%82%BC%EC%84%B1%EA%B7%B8%EB%A3%B9_%EB%A1%9C%EA%B3%A0.png'),(21,'롯데카드','https://i-invdn-com.akamaized.net/content/pic57d2512b61eb50267cc1eae5c327c8b5.jpg'),(22,'신한카드','https://www.shinhancard.com/pconts/company/images/contents/shc_symbol_ci.png'),(23,'KB국민카드','https://mblogthumb-phinf.pstatic.net/20160728_194/ppanppane_1469696183585pXt1k_PNG/KB%BC%D5%C7%D8%BA%B8%C7%E8_%283%29.png?type=w800'),(24,'하나카드','https://images.roa.ai/company_logo/IlNL9KVS.png'),(25,'BC 바로카드','https://www.bccard.com/images/company/cyber/symbol_mark_banner.jpg'),(26,'IBK기업은행','https://t1.daumcdn.net/cfile/tistory/2709143F54D0972024'),(27,'엔에이치엔페이코','https://image.toast.com/aaaaac/paycoNoti/payco_com.jpg'),(28,'토스','https://wp-blog.toss.im/wp-content/uploads/2021/03/SNS-tossfeed-Profile-3.png'),(29,'MG새마을금고','https://modo-phinf.pstatic.net/20200316_183/1584349724954YxCpJ_PNG/mosaHSorLE.png?type=w720'),(30,'트래블월렛','https://oopy.lazyrockets.com/api/v2/notion/image?src=https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fa581b0ec-2f10-4f13-8e3b-d2df1df5cb5c%2F2021_%ED%8A%B8%EB%9E%98%EB%B8%94%EC%9B%94%EB%A0%9B_%EC%B5%9C%EC%A2%85%EB%A1%9C%EA%B3%A0-%EC%95%84%EC%9D%B4%EC%BD%98.png&blockId=cad3543c-baba-43ec-b3ca-528e7d57b186&width=256https://oopy.lazyrockets.com/api/v2/notion/image?src=https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fa581b0ec-2f10-4f13-8e3b-d2df1df5cb5c%2F2021_%ED%8A%B8%EB%9E%98%EB%B8%94%EC%9B%94%EB%A0%9B_%EC%B5%9C%EC%A2%85%EB%A1%9C%EA%B3%A0-%EC%95%84%EC%9D%B4%EC%BD%98.png&blockId=cad3543c-baba-43ec-b3ca-528e7d57b186&width=256'),(31,'카카오페이','https://blog.kakaocdn.net/dn/cEaPmw/btrcIUODymI/EBvA7nx7wVTcdLIrgiVsJK/img.jpg'),(32,'한화투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/32_한화투자.png'),(33,'DB금융','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/33_DB금융.png'),(34,'KB증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/34_KB증권.png'),(35,'다올투자증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/35_다올투자증권.png'),(36,'NH투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/36_NH투자.png'),(37,'SK증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/37_SK증권.png'),(38,'교보증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/38_교보증권.png'),(39,'대신증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/39_대신증권.png'),(40,'메리츠증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/40_메리츠증권.jpg'),(41,'미래에셋대우','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/41_미래에셋대우.jfif'),(42,'부국증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/42_부국증권.png'),(43,'삼성증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/43_삼성증권.png'),(44,'신영증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/44_신영증권.png'),(45,'신한금융','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/45_신한금융.png'),(46,'유안타증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/46_유안타증권.png'),(47,'유진투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/37_유진투자.png'),(48,'이베스트','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/48_이베스트.png'),(49,'케이프투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/49_케이프투자.png'),(50,'키움증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/50_키움증권.png'),(51,'하나금융','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/04_하나.png'),(52,'하이투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/52_하이투자.png'),(53,'현대차투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/53_현대차투자.png'),(54,'한국포스증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/54_한국포스증권.png'),(55,'한국투자','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/55_한국투자.png'),(56,'카카오페이증권','https://gamulbucket2022.s3.ap-northeast-2.amazonaws.com/cplogo/56_카카오페이증권.jfif');
/*!40000 ALTER TABLE `corporation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 11:10:44
